import os
import io
import math
import json
import base64
import psutil
import asyncio
import logging
import aiohttp
from datetime import datetime
from PIL import Image
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)

from ApiGet5sim import buscar_servicos_por_pais 

# ======= CONFIG LOG ======= 

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)
start_time = datetime.now()

class BotManager:
    def __init__(self):
        self.config = json.load(open('config.json', encoding='utf-8'))
        self.users_file, self.gifts_file, self.menu_image = 'data/users.json', 'data/gifts.json', 'data/menu.jpg'
        os.makedirs('data', exist_ok=True)
        for f in [self.users_file, self.gifts_file]:
            if not os.path.exists(f): json.dump({}, open(f, 'w', encoding='utf-8'))

    def _load(self, file): return json.load(open(file, encoding='utf-8'))
    def _save(self, file, data): json.dump(data, open(file, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
    def load_users(self): return self._load(self.users_file)
    def save_users(self, users): self._save(self.users_file, users)
    def load_gifts(self): return self._load(self.gifts_file)
    def save_gifts(self, gifts): self._save(self.gifts_file, gifts)
    def is_admin(self, user_id): return user_id in self.config['admin_id'] if isinstance(self.config['admin_id'], list) else user_id == self.config['admin_id']

    def get_or_create_user(self, user):
        users, uid = self.load_users(), str(user.id)
        if uid not in users:
            users[uid] = {
                "id": user.id,
                "nome": user.first_name or "Usuário",
                "username": user.username or "sem_username",
                "data_start": datetime.now().strftime("%Y-%m-%d"),
                "max_comandos": 0, "ultimo_comando": datetime.now().strftime("%Y-%m-%d"),
                "saldo": 0.0, "numeros_comprados": 0, "recargas_feitas": 0.0,
                "gifts_resgatados": 0.0, "saldo_afiliado": 0.0, "indicacoes": 0
            }
            self.save_users(users)
        return users[uid]

bot_manager = BotManager()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_data = bot_manager.get_or_create_user(user)

    pais_info = user_data.get("pais", {})
    if isinstance(pais_info, dict):
        pais_nome = pais_info.get("nome", "🌎 Não selecionado")
    else:
        pais_nome = str(pais_info) if pais_info else "🌎 Não selecionado"

    user_id = user_data['id']
    user_link = f"<a href='tg://user?id={user_id}'>{user_id}</a>"

    welcome_text = f"""
💜 <b>Bem-vindo(a), {user_data['nome']}!</b>

🤖 Você está no <b>{bot_manager.config['nome']}</b> — a melhor plataforma para gerar números temporários e receber SMS de qualquer serviço, app ou site.

🏷️ <b>ID:</b> {user_link}
🌍 <b>País atual:</b> {pais_nome}
💰 <b>Saldo:</b> R$ {user_data['saldo']:.2f}

📘 Antes de continuar, leia nossos /termos.

🚀 Pronto pra começar? Explore o menu abaixo:
"""

    keyboard = [
        [
            InlineKeyboardButton("🌍 Países", callback_data="paises"),
            InlineKeyboardButton("🛠️ Services", callback_data="services")
        ],
        [InlineKeyboardButton("📢 Canal", url="https://t.me/SmsHunterFy")],
        [
            InlineKeyboardButton("💎 Recarregar", callback_data="recarregar"),
            InlineKeyboardButton("👤 Perfil", callback_data="perfil")
        ],
        [InlineKeyboardButton("🗑️ Apagar Menu", callback_data="apagar_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    try:
        if os.path.exists(bot_manager.menu_image):
            with open(bot_manager.menu_image, 'rb') as photo:
                if update.callback_query:
                    try:
                        await update.callback_query.message.edit_caption(
                            caption=welcome_text,
                            reply_markup=reply_markup,
                            parse_mode=ParseMode.HTML,
                            disable_web_page_preview=True
                        )
                    except:
                        await update.callback_query.message.delete()
                        await context.bot.send_photo(
                            chat_id=update.effective_chat.id,
                            photo=photo,
                            caption=welcome_text,
                            reply_markup=reply_markup,
                            parse_mode=ParseMode.HTML,
                            disable_web_page_preview=True
                        )
                else:
                    await update.message.reply_photo(
                        photo=photo,
                        caption=welcome_text,
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.HTML,
                        disable_web_page_preview=True
                    )
        else:
            if update.callback_query:
                try:
                    await update.callback_query.message.edit_text(
                        welcome_text,
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.HTML,
                        disable_web_page_preview=True
                    )
                except:
                    await update.callback_query.message.delete()
                    await context.bot.send_message(
                        chat_id=update.effective_chat.id,
                        text=welcome_text,
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.HTML,
                        disable_web_page_preview=True
                    )
            else:
                await update.message.reply_text(
                    welcome_text,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True
                )
    except Exception as e:
        logger.error(f"Erro no start: {e}")

# ======== TERMOS ========

async def termos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    termos_text = """
😃 <b>Para que serve esse bot?</b>
...
📲 <b>Nosso canal:</b> @SmsHunterfy
"""
    await update.message.reply_text(
        termos_text,
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

        
# ======== MOSTRAS PAISES ========

async def mostrar_paises(update: Update, context: ContextTypes.DEFAULT_TYPE, pagina=0):
    country = json.load(open("necessary/country.json", "r", encoding="utf-8"))
    user = update.effective_user
    pais_atual = bot_manager.get_or_create_user(user).get("pais_atual")

    lista = list(country.keys())
    por_pag = 70
    ini, fim = pagina * por_pag, pagina * por_pag + por_pag

    botoes = []
    for i in range(ini, min(fim, len(lista)), 2):
        linha = []
        for j in (0,1):
            if i+j < len(lista):
                p = lista[i+j]
                nome = country[p]["nome"] + (" (selecionado)" if pais_atual == p else "")
                linha.append(InlineKeyboardButton(nome, callback_data=f"pais_{p}"))
        botoes.append(linha)

    nav = []
    if pagina > 0: nav.append(InlineKeyboardButton("🔙 Anterior", callback_data=f"paises_{pagina-1}"))
    if fim < len(lista): nav.append(InlineKeyboardButton("🔜 Próxima", callback_data=f"paises_{pagina+1}"))
    if nav: botoes.append(nav)

    botoes.append([InlineKeyboardButton("🔙 Voltar Menu", callback_data="voltar_menu")])

    total = (len(lista)+por_pag-1)//por_pag
    texto = f"🌍 Escolha seu país (página {pagina+1}/{total}):"
    rm = InlineKeyboardMarkup(botoes)

    if update.callback_query: 
        await update.callback_query.message.edit_text(texto, reply_markup=rm)
    else: 
        await update.message.reply_text(texto, reply_markup=rm)


async def selecionar_pais(update: Update, context: ContextTypes.DEFAULT_TYPE, pais_id):
    country = json.load(open("necessary/country.json", "r", encoding="utf-8"))
    if pais_id not in country:
        return await update.callback_query.answer("País inválido.")

    user = update.effective_user
    users = bot_manager.load_users()
    uid = str(user.id)

    if uid not in users:
        bot_manager.get_or_create_user(user)
        users = bot_manager.load_users()

    users[uid].update({"pais": country[pais_id], "pais_id": pais_id, "pais_atual": pais_id})
    bot_manager.save_users(users)

    await update.callback_query.answer(f"✅ {country[pais_id]['nome']} selecionado!")
    await mostrar_paises(update, context)


# ========== CALLBACK PIX ==========
async def recarga(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("⚡ PIX Automático", callback_data="pix_auto")],
        [InlineKeyboardButton("⬅️ Voltar", callback_data="voltar_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.message.edit_text("💎 Escolha o método de recarga:", reply_markup=reply_markup)


async def pix_auto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = update.effective_user
    user_data = bot_manager.get_or_create_user(user)
    user_id = str(user.id)

    users = bot_manager.load_users()
    pagamento_ativo = context.user_data.get("pagamento_ativo")
    if pagamento_ativo:
        await query.message.edit_text("⚠️ Você já tem uma recarga pendente. Digite /cancelar para cancelar antes de iniciar outra.")
        return

    texto = (
        "🔥 Recarregando a partir de <b>R$ 10</b> você ganha um bônus de <b>10%</b>!\n\n"
        "💰 Valor mínimo para recarga: <b>R$ 9.00</b>\n\n"
        "❌ Se desejar cancelar, digite <code>/cancelar</code>\n\n"
        "😀 Pagamento automático por PIX selecionado.\n\n"
        "Digite o valor que deseja recarregar:"
    )
    await query.message.edit_text(texto, parse_mode=ParseMode.HTML)
    context.user_data["aguardando_valor_recarga"] = True


# ========== RECEBE VALOR ==========
async def handle_valor_recarga(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("aguardando_valor_recarga"):
        return

    user = update.effective_user
    user_data = bot_manager.get_or_create_user(user)
    user_id = str(user.id)

    valor_txt = update.message.text.strip().replace(",", ".")
    try:
        valor = float(valor_txt)
    except:
        await update.message.reply_text("⚠️ Valor inválido. Digite um número, ex: 15.50")
        return

    if valor < 9:
        await update.message.reply_text("⚠️ Valor mínimo para recarga é R$ 9.00")
        return

    context.user_data["aguardando_valor_recarga"] = False
    context.user_data["pagamento_ativo"] = True

    payload = {
        "usuario_id": user_id,
        "nome": user_data["nome"],
        "email": f"{user_id}@gmail.com",
        "valor": valor,
        "ip": "127.0.0.1"
    }
    
    headers = {"x-api-key": "f2c286b2a259ee0e0051883f63b85aae6ba5b8bb0e526fcb58834e92975bac54"}

    await update.message.reply_text("⏳ Gerando pagamento...")

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post("http://localhost:3000/sunize/gerar_pagamento", json=payload, headers=headers) as resp:
                data = await resp.json()
    except Exception as e:
        await update.message.reply_text(f"❌ Erro ao conectar com a API: {e}")
        context.user_data["pagamento_ativo"] = False
        return

    if not data.get("success"):
        await update.message.reply_text(f"❌ Erro: {data.get('error', 'Falha desconhecida')}")
        context.user_data["pagamento_ativo"] = False
        return

    pagamento = data["pagamento"]
    qr_path = pagamento["qrFile"]

    # Enviar QR + código
    if os.path.exists(qr_path):
        with open(qr_path, "rb") as img:
            await update.message.reply_photo(
                photo=img,
                caption=f"💰 Valor: R$ {valor:.2f}\n\n📲 Copie e cole o código abaixo no app do seu banco:\n\n<code>{pagamento['pix']['payload']}</code>\n\n⏱️ Você tem 5 minutos para pagar.",
                parse_mode=ParseMode.HTML
            )
    else:
        await update.message.reply_text(
            f"💰 Valor: R$ {valor:.2f}\n\n📲 Copie e cole o código abaixo no app do seu banco:\n\n<code>{pagamento['pix']['payload']}</code>\n\n⏱️ Você tem 5 minutos para pagar.",
            parse_mode=ParseMode.HTML
        )

    # Espera 5 minutos e checa status
    async def verificar_status():
        try:
            await asyncio.sleep(300)
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://localhost:3000/sunize/status/{pagamento['id']}", headers=headers) as resp:
                    status_data = await resp.json()

            if status_data.get("success") and status_data["status"] == "PAID":
                users = bot_manager.load_users()
                bonus = valor * 0.10 if valor >= 10 else 0
                total_add = valor + bonus
                users[user_id]["saldo"] += total_add
                users[user_id]["recargas_feitas"] += valor
                bot_manager.save_users(users)

                await update.message.reply_text(f"✅ Pagamento confirmado!\n💰 Valor adicionado: R$ {total_add:.2f}")
            else:
                await update.message.reply_text("⌛ Tempo expirado! Pagamento cancelado automaticamente.")
        except Exception as e:
            logger.error(f"Erro ao verificar status: {e}")

        context.user_data["pagamento_ativo"] = False

    asyncio.create_task(verificar_status())


# ========== CANCELAR ==========
async def cancelar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("pagamento_ativo"):
        await update.message.reply_text("❌ Nenhum pagamento ativo no momento.")
        return
    context.user_data["pagamento_ativo"] = False
    context.user_data["aguardando_valor_recarga"] = False
    await update.message.reply_text("🛑 Pagamento cancelado com sucesso.")

async def perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = update.effective_user
    user_data = bot_manager.get_or_create_user(user)
    bot_username = (await context.bot.get_me()).username
    
    link_afiliado = f"https://t.me/{bot_username}?start={user_data['id']}"
    
    perfil_text = f"""
👤 <b>PERFIL</b>:
<b>Nome:</b> <code>{user_data['nome']}</code>
<b>Username:</b> <code>@{user_data['username']}</code>
<b>ID:</b> <code>{user_data['id']}</code>

💰 <b>CARTEIRA</b>:
<b>ID carteira:</b> {user_data['id']}
<b>Seu saldo atual:</b> R${user_data['saldo']:.2f}

🛒 <b>COMPRAS</b>:
<b>Números comprados:</b> {user_data['numeros_comprados']}
<b>Recargas feitas:</b> R${user_data['recargas_feitas']:.2f}
<b>Gifts resgatados:</b> R${user_data['gifts_resgatados']:.2f}

👥 <b>AFILIADOS</b>:
<b>Saldo ganho:</b> R${user_data['saldo_afiliado']:.2f}
<b>Indicações:</b> {user_data['indicacoes']}

🔗 <b>Link de afiliado:</b>
<code>{link_afiliado}</code>
"""

    keyboard = [
        [InlineKeyboardButton("⬅️ Voltar", callback_data="voltar_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    try:
        await query.message.edit_text(
            perfil_text, 
            reply_markup=reply_markup, 
            parse_mode=ParseMode.HTML
        )
    except:
        await query.message.edit_caption(
            caption=perfil_text, 
            reply_markup=reply_markup, 
            parse_mode=ParseMode.HTML
        )

start_time = datetime.now()

async def fotomenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id):
        return
    
    await update.message.reply_text("📸 Por favor, envie a nova foto do menu:")
    context.user_data['waiting_photo'] = True

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get('waiting_photo'):
        if not bot_manager.is_admin(update.effective_user.id):
            return
        
        photo_file = await update.message.photo[-1].get_file()
        await photo_file.download_to_drive(bot_manager.menu_image)
        
        await update.message.reply_text("✅ Foto do menu atualizada com sucesso!")
        context.user_data['waiting_photo'] = False

async def add_gift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id): return
    if len(context.args) < 2: return await update.message.reply_text("⚠️ Uso: /add_gift <nome> <valor>")

    gift_name = context.args[0]
    try: gift_value = float(context.args[1])
    except: return await update.message.reply_text("⚠️ O valor deve ser um número!")

    gifts = bot_manager.load_gifts()
    gifts[gift_name] = {
        "valor": gift_value,
        "criado_por": update.effective_user.id,
        "data_criacao": datetime.now().strftime("%Y-%m-%d"),
        "resgatado": False,
        "resgatado_por": None,
        "data_resgate": None
    }
    bot_manager.save_gifts(gifts)
    await update.message.reply_text(f"✅ Gift '{gift_name}' criado com valor R${gift_value:.2f}!")


async def resgatar_gift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1: return await update.message.reply_text("⚠️ Uso: /resgatar_gift <nome>")
    gift_name = context.args[0]
    gifts = bot_manager.load_gifts()

    if gift_name not in gifts: return await update.message.reply_text("⚠️ Esse gift não existe.")
    gift = gifts[gift_name]
    if gift["resgatado"]: return await update.message.reply_text("❌ Esse gift já foi resgatado.")

    gift.update({
        "resgatado": True,
        "resgatado_por": update.effective_user.id,
        "data_resgate": datetime.now().strftime("%Y-%m-%d")
    })
    bot_manager.save_gifts(gifts)

    users = bot_manager.load_users()
    uid = str(update.effective_user.id)
    users[uid]["saldo"] += gift["valor"]
    users[uid]["gifts_resgatados"] += gift["valor"]
    bot_manager.save_users(users)

    await update.message.reply_text(
        f"🎉 Parabéns! Você resgatou o gift {gift_name}.\n"
        f"Seu saldo agora é R${users[uid]['saldo']:.2f} 💰"
    )


async def del_gift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id): return
    if len(context.args) < 1: return await update.message.reply_text("⚠️ Uso: /del_gift <nome>")

    gift_name = context.args[0]
    gifts = bot_manager.load_gifts()

    if gift_name in gifts:
        del gifts[gift_name]
        bot_manager.save_gifts(gifts)
        await update.message.reply_text(f"✅ Gift '{gift_name}' deletado!")
    else:
        await update.message.reply_text("⚠️ Esse gift não existe.")


async def infogifts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id): return

    gifts = bot_manager.load_gifts()
    if not gifts: return await update.message.reply_text("📋 Nenhum gift cadastrado.")

    gifts_json = json.dumps(gifts, indent=2, ensure_ascii=False)
    await update.message.reply_text(f"📋 GIFTS:\n```json\n{gifts_json}\n```", parse_mode=ParseMode.MARKDOWN)


async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id): return

    users = bot_manager.load_users()
    data = json.dumps(users, indent=2, ensure_ascii=False)

    path = "data/users_export.json"
    with open(path, "w", encoding="utf-8") as f: f.write(data)

    with open(path, "rb") as f:
        await update.message.reply_document(
            document=f,
            filename=f"users_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            caption=f"📋 Total de usuários: {len(users)}"
        )

async def transmitir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_manager.is_admin(update.effective_user.id): return
    await update.message.reply_text(
        "📢 Digite a mensagem para transmitir.\n\nUse HTML:\n<b>negrito</b> <i>itálico</i> <code>código</code> <a href='url'>link</a>\n\n"
        "📌 Botões inline (opcional), use JSON:\n"
        "<b>Promoção!</b>\n```json\n[[{\"text\":\"🎁 Ver\",\"url\":\"https://t.me/SmsHunterFy\"}]]\n```\n\n"
        "Múltiplas linhas:\n```json\n[[{\"text\":\"1\",\"url\":\"https://1.com\"}],[{\"text\":\"2\",\"url\":\"https://2.com\"}]]```",
        parse_mode=ParseMode.HTML
    )
    context.user_data["waiting_broadcast"] = True


async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("waiting_broadcast"): return
    if not bot_manager.is_admin(update.effective_user.id): return

    txt = update.message.text
    reply_markup = None

    try:
        if "```json" in txt:
            p = txt.split("```json")
            txt, js = p[0].strip(), p[1].split("```")[0].strip()
            data = json.loads(js)
        elif "[[" in txt:
            i = txt.find("[[")
            data = json.loads(txt[i:])
            txt = txt[:i].strip()
        else:
            data = None

        if data:
            kb = [[InlineKeyboardButton(btn["text"], url=btn["url"]) for btn in row] for row in data]
            reply_markup = InlineKeyboardMarkup(kb)

    except Exception as e:
        await update.message.reply_text(f"⚠️ Erro ao processar JSON: {e}\nEnviando sem botões...")

    users = bot_manager.load_users()
    success = failed = 0

    for uid in users:
        try:
            await context.bot.send_message(int(uid), txt, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
            success += 1
            await asyncio.sleep(0.05)
        except Exception as e:
            logger.error(f"Erro ao enviar {uid}: {e}")
            failed += 1

    await update.message.reply_text(f"✅ Concluído!\nEnviadas: {success}\nFalhas: {failed}")
    context.user_data["waiting_broadcast"] = False

async def comandos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    comandos_text = """📋 Comandos do ADM:
- /status
- /fotomenu
- /add_gift <nome> <valor>
- /del_gift <nome>
- /infogifts
- /users
- /transmitir

📋 Comandos gerais:
- /start
- /resgatar_gift <nome>"""
    
    await update.message.reply_text(comandos_text)
    
def buscar_servicos_por_pais(country):
    url = f"https://5sim.net/v1/guest/products/{country}/any"
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        data = r.json()

        # JSON válido E é um dicionário
        if isinstance(data, dict):
            return data

        # Caso venha lista (raro)
        if isinstance(data, list):
            novo = {}
            for item in data:
                if isinstance(item, dict) and "name" in item:
                    nome = item["name"]
                    novo[nome] = item
            return novo

        return {}

    except Exception as e:
        print("ERRO JSON 5SIM:", e)
        return {}

async def mostrar_servicos(update: Update, context: ContextTypes.DEFAULT_TYPE, pagina: int = 0):
    query = update.callback_query
    user_id = str(update.effective_user.id)

    users = bot_manager.load_users()
    u = users.get(user_id)

    if not u or "pais_id" not in u:
        await query.message.reply_text("Selecione um país primeiro.")
        return

    country = u["pais_id"]

    # BUSCA REAL
    data = buscar_servicos_por_pais(country)

    if not isinstance(data, dict) or len(data) == 0:
        await query.message.edit_text("Nenhum serviço encontrado para este país.")
        return

    # FILTRAGEM
    services = []
    for name, info in data.items():
        if not isinstance(info, dict):
            continue

        qty = info.get("Qty") or info.get("qty")
        price = info.get("Price") or info.get("price")

        if price is None or qty is None:
            continue

        services.append({
            "name": name,
            "qty": qty,
            "price": price
        })

    if not services:
        await query.message.edit_text("Nenhum serviço disponível no momento.")
        return

    # PAGINAÇÃO
    per_page = 16
    total = len(services)
    start = pagina * per_page
    end = start + per_page

    page_services = services[start:end]

    keyboard = []
    row = []

    for idx, svc in enumerate(page_services):
        label = f"{svc['name']} | {svc['price']}₽"
        btn = InlineKeyboardButton(label, callback_data=f"servico_{svc['name']}")
        row.append(btn)

        if (idx + 1) % 4 == 0:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    # NAVEGAÇÃO
    nav = []
    if pagina > 0:
        nav.append(InlineKeyboardButton("⬅️ Anterior", callback_data=f"services_{pagina-1}"))
    if end < total:
        nav.append(InlineKeyboardButton("Próxima ➡️", callback_data=f"services_{pagina+1}"))

    if nav:
        keyboard.append(nav)

    keyboard.append([InlineKeyboardButton("Menu", callback_data="voltar_menu")])

    await query.message.edit_text(
        f"Serviços disponíveis — {country}\nPágina {pagina + 1}",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    if data == "perfil":
        await perfil(update, context)
    elif data == "voltar_menu":
        await start(update, context)
    elif data == "apagar_menu":
        await query.answer("Menu apagado!")
        try:
            await query.message.delete()
        except:
            pass
    elif data == "recarregar":
        await recarga(update, context)
    elif data == "pix_auto":
        await pix_auto(update, context)
    elif data == "paises":
        await mostrar_paises(update, context)
    elif data.startswith("pais_"):
        await selecionar_pais(update, context, data.split("_")[1])
    elif data == "paises_next":
        await paginar_paises(update, context, 1)
    elif data == "paises_back":
        await paginar_paises(update, context, -1)
    elif data == "services":
        await mostrar_servicos(update, context)
    elif data.startswith("servico_"):
        await selecionar_servico(update, context, data.split("_")[1])
    elif data.startswith("services_"):
        pagina = int(data.split("_")[1])
        await mostrar_servicos(update, context, pagina)
   
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get("waiting_broadcast"):
        await handle_broadcast(update, context)
    elif context.user_data.get("aguardando_valor_recarga"):
        await handle_valor_recarga(update, context)


def main():
    application = Application.builder().token(bot_manager.config['token']).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("fotomenu", fotomenu))
    application.add_handler(CommandHandler("add_gift", add_gift))
    application.add_handler(CommandHandler("resgatar_gift", resgatar_gift))
    application.add_handler(CommandHandler("del_gift", del_gift))
    application.add_handler(CommandHandler("infogifts", infogifts))
    application.add_handler(CommandHandler("users", users_command))
    application.add_handler(CommandHandler("transmitir", transmitir))
    application.add_handler(CommandHandler("comandos", comandos))
    application.add_handler(CommandHandler("cancelar", cancelar))
    application.add_handler(CommandHandler("termos", termos))

    application.add_handler(
        CallbackQueryHandler(
            lambda u, c: mostrar_paises(u, c, int(u.callback_query.data.split('_')[1])),
            pattern=r"^paises_\d+$"
        )
    )

    application.add_handler(
        CallbackQueryHandler(
            lambda u, c: mostrar_servicos(u, c, int(u.callback_query.data.split('_')[1])),
            pattern=r"^services_\d+$"
        )
    )

    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
