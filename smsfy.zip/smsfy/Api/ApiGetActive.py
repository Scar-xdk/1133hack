import aiohttp
import json

API_TOKEN = "0943fb3145c442f33b0cA9fddbdd2754"
BASE_URL = "https://api.sms-activate.ae/stubs/handler_api.php"

async def _req(action, **kwargs):
    async with aiohttp.ClientSession() as session:
        params = {"api_key": API_TOKEN, "action": action}
        params.update(kwargs)
        async with session.get(BASE_URL, params=params) as resp:
            text = await resp.text()
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return text

# curl: ?api_key=TOKEN&action=getPrices&country=73
# mostra os serviços por país
async def get_services(country_id):
    return await _req("getPrices", country=country_id)

# curl: ?api_key=TOKEN&action=getBalance
# consulta saldo
async def get_balance():
    return await _req("getBalance")

# curl: ?api_key=TOKEN&action=getNumber&service=service&country=73
# pede número
async def get_number(service, country, operator=None):
    params = {"service": service, "country": country}
    if operator:
        params["operator"] = operator
    return await _req("getNumber", **params)

# curl: ?api_key=TOKEN&action=getStatus&id=ID
# verifica status do número
async def get_status(id_activation):
    return await _req("getStatus", id=id_activation)

# curl: ?api_key=TOKEN&action=setStatus&id=ID&status=1
# marca número como pronto pra receber SMS
async def ready_number(id_activation):
    return await _req("setStatus", id=id_activation, status=1)

# curl: ?api_key=TOKEN&action=setStatus&id=ID&status=6
# confirma o código recebido
async def confirm_number(id_activation):
    return await _req("setStatus", id=id_activation, status=6)

# curl: ?api_key=TOKEN&action=setStatus&id=ID&status=8
# cancela o número
async def cancel_number(id_activation):
    return await _req("setStatus", id=id_activation, status=8)

# curl: ?api_key=TOKEN&action=getActiveActivations
# ativações ativas
async def get_active_activations():
    return await _req("getActiveActivations")

# curl: ?api_key=TOKEN&action=getActivationHistory
# histórico de ativações
async def get_activation_history():
    return await _req("getActivationHistory")

# curl: ?api_key=TOKEN&action=QUALQUER&param1=x&param2=y
# chamada genérica de rota manual
async def call_api(action, **params):
    return await _req(action, **params)
